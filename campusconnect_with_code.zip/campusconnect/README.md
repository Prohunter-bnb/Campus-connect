# CampusConnect
This is a local PHP project using file-based storage.